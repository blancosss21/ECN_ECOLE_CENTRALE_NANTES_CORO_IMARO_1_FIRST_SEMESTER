#include <sudoku/grid.h>
#include <iostream>
#include <chrono>

Grid::Grid(int argc, char** argv, std::string start, bool display): display{display}
{
  const auto starting_grid{getStart(argc, argv, start)};

  if(std::any_of(argv, argv+argc,[](const std::string &arg){return arg == "-d";}))
  {
    // force display
    this->display = true;
  }
  else if(std::any_of(argv, argv+argc,[](const std::string &arg){return arg == "-n";}))
  {
    // force no display
    this->display = false;
  }

  // build grid
  uint row = 0;
  for(const auto &line: starting_grid)
  {
    uint col = 0;
    for(const auto &elem: line)
    {
      cells[9*row + col].init(row, col, cells, elem);
      col++;
    }
    row++;
  }

  // erase candidates according to initial grid
  for(const auto &cell: cells)
  {
    if(!cell.digit) continue;

    for(auto &nb: cell.neighboors)
    {
      if(auto elem{std::find(nb->candidates.begin(), nb->candidates.end(), cell.digit)};
         elem != nb->candidates.end())
        nb->candidates.erase(elem);
    }
  }
}

void Grid::solve()
{
  using Clock = std::chrono::high_resolution_clock;
  const auto start{Clock::now()};
  const auto result{solveNextCell()};
  const auto end{Clock::now()};

  print();

  std::cout << "Solved in "
            << std::chrono::duration_cast<std::chrono::microseconds>(end-start).count()
            << " \u03BCs\n";

  if(result && std::all_of(cells.begin(), cells.end(), Cell::isValid))
    std::cout << "Sudoku was solved with "
              << guesses << " wild guesses, "
                            "had to cancel and go back " << cancels << " times" << std::endl;
  else
    std::cout << "Grid is not valid" << std::endl;
}

void Grid::print() const
{
  constexpr auto line{" -----------"};

  std::cout << line << '\n';

  auto cell{cells.begin()};
  for(auto row = 0; row < 9; ++row)
  {
    std::cout << ' ';
    for(auto col = 0; col < 9; ++col)
    {
      std::cout << (cell++)->symbol();
      if(col == 2 || col == 5)
        std::cout << '|';
      else if(col == 8)
        std::cout << '\n';
    }
    if(row == 2 || row == 5 || row == 8)
      std::cout << line << '\n';
  }
  std::cout << std::endl;
}


// TODO section


/// Returns True if c1 is considered a better next cell to investigate
/// than c2, False otherwise
/// BONUS improve the current version by taking into account the number of candidates

////3.6 Huge bonus: find my bug
//When trying to do smarter things in the bestNextCell function the solver sometimes (e.g.
//depending on the initial grid) tells that there is no solution to the grid. I have no idea why.
//Original Version of the function:
//bool bestNextCellOriginal(const Cell &c1, const Cell &c2)
//{
//  return c1.digit < c2.digit;
//}

//Answer: The issue might be due to the bestNextCell function trying to compare already assigned cells
//(i.e., those with a digit different from zero) with unassigned ones
//(i.e., those with a digit equal to zero). This could lead to choosing an already assigned cell
//as the “best” next cell, which doesn’t make sense as there’s no need to further investigate an
//already assigned cell.
//A possible way to fix this issue could be to modify the bestNextCell function so that it discards
//already assigned cells when looking for the “best” next cell.

bool bestNextCell(const Cell &c1, const Cell &c2)
{
  // If both cells are not assigned, compare their number of candidates
  if (c1.digit == 0 && c2.digit == 0)
    return c1.candidates.size() < c2.candidates.size();
  // If only one of the cells is not assigned, that cell should be investigated first
  else if (c1.digit == 0)
    return true;
  else if (c2.digit == 0)
    return false;
  // If both cells are assigned, neither should be investigated
  else
    return false;
}



//// 3.4 BONUS improve the current version by taking into account the number of candidates
//bool bestNextCell(const Cell &c1, const Cell &c2)
//{
//  // If both cells are not assigned, compare the size of their candidate lists
//  if (c1.digit == 0 && c2.digit == 0)
//    return c1.candidates.size() < c2.candidates.size();
//  // If only one of the cells is not assigned, that cell should be investigated first
//  else if (c1.digit == 0)
//    return true;
//  else if (c2.digit == 0)
//    return false;
//  // If both cells are assigned, compare their digits as before
//  else
//    return c1.digit < c2.digit;
//}




/// main backtracking function
///3.1 You have to implement the solveNextCell() method as shown in Algorithm 1
bool Grid::solveNextCell()
{
  // check if the grid is already full
  if (std::all_of(cells.begin(), cells.end(), Cell::isAssigned))
    return true;

  // identify next cell to go, it is just the best under whatever bestNextCell considers
  auto &next_cell{*std::min_element(cells.begin(), cells.end(), bestNextCell)};

  // just a check, it is meaningless to continue with an already solved cell
  if(next_cell.digit)
    throw std::runtime_error("Next cell already has a digit");


////3.1 Basic Version
//  // backtracking algorithm candidate loop
//  for (auto guess : next_cell.candidates)
//  {
//    // check if the guess is feasible for the next cell
//    if (next_cell.couldBe(guess))
//    {
//      // set the guess for the next cell and prune it from its neighbors
//      next_cell.setGuess(guess);

//      // recursively try to solve the next cell
//      if (solveNextCell())
//        return true;

//      // if the recursive call failed, cancel the guess for the next cell
//      next_cell.cancelGuess();
//    }
//  }


////3.5 BONUS VERSION: backtracking algorithm candidate loop
  for (auto guess : next_cell.candidates)
  {
    // check if the guess is feasible for the next cell
    if (next_cell.couldBe(guess))
    {
      // set the guess for the next cell and prune it from its neighbors
      next_cell.setGuess(guess);
      guesses++;  // increment guesses

      // recursively try to solve the next cell
      if (solveNextCell())
        return true;

      // if the recursive call failed, cancel the guess for the next cell
      next_cell.cancelGuess();
      cancels++;
    }
  }


  // tried all candidates for this cell, without success
  return false;
}



