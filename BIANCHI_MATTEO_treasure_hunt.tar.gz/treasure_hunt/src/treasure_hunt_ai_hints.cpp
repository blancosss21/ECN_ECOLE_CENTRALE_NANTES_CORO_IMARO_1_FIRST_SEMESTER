#include <treasure_hunt_ai.h>
#include <duels/utils/grid_point.h>
#include <duels/algo/a_star.h>
constexpr int FREE{0};
constexpr int ROCK{1};
constexpr int UNKNOWN{2};

Orientation leftFrom(const Orientation &orientation) {
    // Implement the logic to get the left orientation
    if (orientation == Orientation::UP) {
        return Orientation::LEFT;
    } else if (orientation == Orientation::LEFT) {
        return Orientation::DOWN;
    } else if (orientation == Orientation::DOWN) {
        return Orientation::RIGHT;
    } else {
        // Orientation::RIGHT
        return Orientation::UP;
    }
}

Orientation rightFrom(const Orientation &orientation) {
    // Implement the logic to get the right orientation
    if (orientation == Orientation::UP) {
        return Orientation::RIGHT;
    } else if (orientation == Orientation::LEFT) {
        return Orientation::UP;
    } else if (orientation == Orientation::DOWN) {
        return Orientation::LEFT;
    } else {
        // Orientation::RIGHT
        return Orientation::DOWN;
    }
}

TreasureHuntAI::TreasureHuntAI()
  : map(20, 30, UNKNOWN) // fill the 20x30 map with 2's (unknown)
{
  // register this map for all grid points
  pose.setMap(map);

  // TODO the treasure may be at any position: update candidates
  for (int x = 0; x < map.width(); ++x)
  {
    for (int y = 0; y < map.height(); ++y)
    {
      candidates.push_back(Vector2D<int>{x, y});
    }
  }
}

Action TreasureHuntAI::computeFrom(const Feedback &feedback)
{
    // 1. Update the Robot's Pose
    pose.set(feedback.pose);

    // If we are here, then it is not a treasure position
    removeCandidate(pose);

    // 2. Update the Map based on Scan Information
    for (const auto &[x, y, rock] : feedback.scan)
    {
        // Update the map based on feedback.scan
        if (rock)
        {
            map.cell(x, y) = ROCK;
        }
        else
        {
            // If there is no rock, mark the cell as FREE
            map.cell(x, y) = FREE;
        }
    }

    // 3. Update Candidates based on Treasure Distance
    const auto threshold{0.5};
    pruneCandidates([&](const Vector2D<int> &candidate)
    {
        // Calculate the Euclidean distance between the current pose and the candidate
        float distanceToCandidate = std::sqrt(std::pow(pose.x - candidate.x, 2) + std::pow(pose.y - candidate.y, 2));

        // Update candidates based on feedback.treasure_distance
        // Return true if this candidate cannot be the treasure position
        bool erase = std::abs(feedback.treasure_distance - distanceToCandidate) >= threshold;

//        // If all candidates are being erased, keep at least one
//        if (erase && candidates.size() == 1)
//        {
//            erase = false;
//        }

//        // Additional check: If the current candidate matches the pose, don't erase it
//        if (candidate == pose)
//        {
//            erase = false;
//        }

//        // If there are no remaining candidates, keep the current one
//        if (erase && candidates.size() == 0)
//        {
//            candidates.push_back(candidate);
//        }

        return erase;
    });

    // Check if the boat is close to the treasure
    if (feedback.treasure_distance < 1.0)
    {
        // Boat is close to the treasure, move directly to the treasure
        return duels::treasure_hunt::Action::MOVE;
    }

    if (candidates.empty())
    {
        // If no candidates left, return a default action
        return duels::treasure_hunt::Action::SONAR;
    }

    // 4. Plan the Next Action using A* Algorithm
    const auto path{Astar(pose, candidates[0])};

    Action action = duels::treasure_hunt::Action::SONAR; // Set a default action

    // Check if a valid path is found
    if (!path.empty())
    {
        const auto next{path[1]};

        // Check if the next pose has a different (x, y) position
        if (pose.x != next.x || pose.y != next.y)
        {
            // If the next cell is FREE, move to that cell
            if (map.cell(next.x, next.y) == FREE)
            {
                action = duels::treasure_hunt::Action::MOVE;
            }
            else
            {
                // If the next cell is a ROCK or UNKNOWN, use SONAR instead
                action = duels::treasure_hunt::Action::SONAR;
            }
        }
        else
        {
            // The positions are the same, so we need to change the orientation
            if (leftFrom(pose.orientation) == next.orientation)
            {
                action = duels::treasure_hunt::Action::TURN_LEFT;
            }
            else if (rightFrom(pose.orientation) == next.orientation)
            {
                action = duels::treasure_hunt::Action::TURN_RIGHT;
            }
        }
    }
    else
    {
        // No valid path found, default to using SONAR
        action = duels::treasure_hunt::Action::SONAR;
    }

    return action;
}
