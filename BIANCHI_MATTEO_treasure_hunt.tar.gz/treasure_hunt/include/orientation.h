#ifndef ORIENTATION_H
#define ORIENTATION_H

enum class OrientationChange
{
    NONE,
    LEFT,
    RIGHT
};

#endif // ORIENTATION_H
