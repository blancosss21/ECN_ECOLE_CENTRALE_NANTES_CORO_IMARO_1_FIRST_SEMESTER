#ifndef GORILLAI_hpp
#define GORILLAI_hpp


class GorillaAI{
    public:
        Input computeFrom(const Feedback &feedback);



}








#endif // GORILLAI_H



