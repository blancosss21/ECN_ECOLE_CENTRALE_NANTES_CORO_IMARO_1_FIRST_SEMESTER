#include <duels/gorillas/game.h>
#include <algorithm>
using namespace duels::gorillas;

class GorillaAI {
public:
    GorillaAI() : kp(0.1), ki(0.01), kd(0.01), integral(0), prevError(0) {}

    Input computeFrom(const Feedback &feedback) {
        bool obstacleInFront = isObstacleInFront(feedback);

        double error_x = feedback.banana.x - feedback.opponent.x;
        double error_y = feedback.banana.y - feedback.opponent.y;

        integral += error_y;
        double derivative = error_x - prevError;

        double controlOutput = kp * error_x + ki * integral + kd * derivative;

        prevError = error_x;

        if (controlOutput < 0) {
            input.vel += std::abs(controlOutput);
        } else {
            input.vel -= controlOutput;
        }

        // Adjust the velocity based on wind strength
        input.vel += 0.5 * feedback.wind;  // Adjust the multiplier as needed

        // Adjust the angle based on the opponent's height
        double heightDifference = feedback.opponent.y - feedback.me.y;
        if (heightDifference > 0) {
            input.angle = std::max(input.angle, static_cast<float>(45.0));
        }

        // Adjust the angle based on wind and obstacles
        double distanceToOpponent = std::hypot(feedback.opponent.x - feedback.me.x, feedback.opponent.y - feedback.me.y);
        input.angle = calculateOptimalAngle(distanceToOpponent, feedback.wind, obstacleInFront);

        // Ensure the velocity is positive
        input.vel = std::max(input.vel, static_cast<float>(0.0));

        return input;
    }

private:
    double kp, ki, kd;
    double integral;
    double prevError;

    Input input;

    double calculateOptimalAngle(double distanceToOpponent, double wind, bool obstacleInFront) {
        double baseAngle = (distanceToOpponent < 200) ? 45.0 : 30.0;

        if (obstacleInFront) {
            input.angle += input.angle + 26.0;
        }

        // Adjust the angle based on wind direction and strength
        if (wind > 0) {
            // Wind is in favor, decrease angle and increase velocity
            return std::max(static_cast<float>(input.angle - 8.0 * wind), static_cast<float>(baseAngle));
        } else {
            // Wind is against, increase angle and decrease velocity
            return std::min(static_cast<float>(input.angle + 8.0 * std::abs(wind)), static_cast<float>(baseAngle));
        }

        // Add a default return statement to address the warning
        return baseAngle;
    }

    bool isObstacleInFront(const Feedback &feedback) {
        // Set the distance threshold for obstacles
        const double obstacleDistanceThreshold = 50.0;

        // Check if there is a building in front of the gorilla
        return feedback.building[static_cast<int>(feedback.me.x)] > feedback.me.y &&
               feedback.building[static_cast<int>(feedback.me.x)] - feedback.me.y < obstacleDistanceThreshold;
    }
};

int main(int argc, char **argv) {
    GorillaAI gorillaAI;
    Game game(argc, argv, "Matteo", 3); // difficulty from 0 to 3

    Input input;
    Feedback feedback;
    const auto timeout = game.timeout_ms();

    while (game.get(feedback)) {
        input = gorillaAI.computeFrom(feedback);
        game.send(input);
    }
}
