function [ ro1, ro2, ro3, beta1, beta2, beta3] = inverse_geometric_model(x, y,phi,R,r,l)
syms ro1_ ro2_ ro3_;


%phi calculated for c1 c2 and c3 from positive x axis.
phi2 = phi + 2*pi/3; %phi plus 120
phi3 = phi + 4*pi/3; %phi plus 240

angleA1= 0 ; %in line with x axis
angleA2= 2*pi/3; %120 from x axis
angleA3= 4*pi/3; %240 from x axis;

angleC1= phi +pi/6;
angleC2= phi2+pi/6;
angleC3= phi3+pi/6;

%using trignometry l^2 = (the x difference)^2 + (the y difference)^2
% need to solve equations to find the value of rho 1 2 and 3
equations = [(x-r*cos(angleC1)+R*cos(pi/6)-ro1_*cos(angleA1))^2 + (y-r*sin(angleC1)+R*sin(pi/6)-ro1_*sin(angleA1))^2   == l^2; %using point B1C1
             (x-r*cos(angleC2)-R*cos(pi/6)-ro2_*cos(angleA2))^2 + (y-r*sin(angleC2)+R*sin(pi/6)-ro2_*sin(angleA2))^2  == l^2;%B2C2
             (x-r*cos(angleC3)-R*cos(pi/2)-ro3_*cos(angleA3))^2 + (y-r*sin(angleC3)-R*sin(pi/2)-ro3_*sin(angleA3))^2  == l^2;%B3C3
    ];

vars = [ro1_, ro2_, ro3_];
[T1, T2, T3,paramams,conditions]=solve(equations, vars,'Real',true, 'ReturnConditions', true);
%store all the possible solutions in this matrix upto 8 solutions 
solutions = [double(T1) double(T2) double(T3)];
beta1 = 0;
beta2 = 0;
beta3 = 0;
ro1 = 0;
ro2 = 0;
ro3 = 0;

%to avoid intersecting solutions check the values of rho is between 0 and
%sqrrt of R
%finding the beta values corresponding to each of these solutions  
for i = 1:size(solutions, 1)
ro1 = solutions(i, 1);
ro2 = solutions(i, 2);
ro3 = solutions(i, 3);

if  isreal(ro1) & 0 < ro1 & ro1 < sqrt(3)*R
    if isreal(ro2) & 0 < ro2 & ro2 < sqrt(3)*R 
        if isreal(ro3) & 0 < ro3 & ro3 < sqrt(3)*R 
            xcomp1= x-r*cos(phi+pi/6)+R*cos(pi/6)-ro1;
            ycomp1= y-r*sin(phi+pi/6)+R*sin(pi/6);
            xcomp2= x-r*cos(phi2+pi/6)-R*cos(pi/6)-ro2*cos(2*pi/3);
            ycomp2= y-r*sin(phi2+pi/6)+R*sin(pi/6)-ro2*sin(2*pi/3);
            xcomp3= x-r*cos(phi3+pi/6)-R*cos(pi/2)-ro3*cos(4*pi/3);
            ycomp3= y-r*sin(phi3+pi/6)-R*sin(pi/2)-ro3*sin(4*pi/3);

            sin_beta1 = ycomp1 / l; 
            cos_beta1 = xcomp1 / l;
            beta1 = double(atan(sin_beta1/cos_beta1));
        
            sin_beta2 = ycomp2 / l; 
            cos_beta2 = xcomp2 / l;
            beta2 = double(atan(sin_beta2/cos_beta2));
        
            sin_beta3 = ycomp3 / l; 
            cos_beta3 = xcomp3 / l;
            beta3 = double(atan(sin_beta3/cos_beta3));
            
           % s=[ro1,ro2,ro3,beta1,beta2,beta3];
           
           
           %return the first possible solution mqtiching the criteria
           
        end
    end
end
end  
end





