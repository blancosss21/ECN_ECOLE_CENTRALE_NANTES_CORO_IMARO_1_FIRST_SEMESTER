function mass = fun(x)
density=7800; 


R = x(1); %circum radius of the base
r = x(2); %circum radius of the moving platform
l = x(3); %length of intermidiate links
c = x(4); %crosssection radius of the links
d = x(5); %thickness of the moving platform
ms=1000;
mass = (pi*(d^2)*r*density) + (3*pi*(c^2)*l*density)+3*ms  ;


