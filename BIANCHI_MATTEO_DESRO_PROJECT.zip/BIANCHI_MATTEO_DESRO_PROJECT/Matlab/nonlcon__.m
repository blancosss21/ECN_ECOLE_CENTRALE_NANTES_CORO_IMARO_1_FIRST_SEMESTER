function [c,ceq] = nonlcon(x)



density=7800; 
R = x(1); %circum radius of the base
r = x(2); %circum radius of the moving platform
l = x(3); %length of intermidiate links
c = x(4); %crosssection radius of the links
d = x(5); %thickness of the moving platform
Rw = 0.1; %rqdius of workspace 50mm or 0.05m
phi_max = pi/3;
               
min_fwd = 1;
min_inv = 1;

for phi = 0.0:phi_max/4:phi_max
   for x1 = -Rw:Rw:Rw
       for y1 = -Rw:Rw:Rw
           if x1^2+y1^2 > Rw^2
               continue
           end    
    [ro1, ro2, ro3,beta1, beta2, beta3] = inverse_geometric_model(x1,y1,phi,R,r,l);
               if ro1 == 0 | ro2 == 0 | ro3 == 0
               continue
           end
    [matrixA,matrixB] = jacobian(ro1, ro2, ro3,beta1,beta2,beta3, phi, r);
%    ICN_fwd_J = 1/cond(matrixA/norm(matrixA));
%    ICN_inv_J = 1/cond(matrixB/norm(matrixB));
    ICN_fwd_J = 1/cond(matrixA);
    if min_fwd > ICN_fwd_J
        min_fwd = ICN_fwd_J;
    end
    ICN_inv_J = 1/cond(matrixB);
    if min_inv > ICN_inv_J
       min_inv = ICN_inv_J;
    end
       end
   end
end


    c(1) = (R/2)-(l+r); %geometric constraint...avoiding intersections between links
    c(2) = 0.1-min_inv; % inverse conditioning number of A > 0.1
    c(3) = 0.1-min_inv; % inverse conditioning number of B > 0.1
    c(4) = 0.1 - (R+l+r);
    c(5) = r - R;


ceq = [];