clc
clear all
close all
   
R_init = 0.1; %initial value for R
r_init = 0.1; %initial value for r
l_init = 0.1; %initial value for l
c_init = 0.01; %initial value for c
d_init = 0.01; %initial value for d


optimum_vals = [R_init,r_init,l_init,c_init,d_init];
lb = [1.e-5, 1.e-5, 1.e-5, 0, 0];  % lower bounds of end effector pos
ub = [4, 4, 4, 0.1, 0.1];  % upper bounds of end effector pos
x0 = [R_init, r_init, l_init, c_init, d_init];


options = optimset( 'Display','Iter',...
                    'TolX',1e-5,...
                    'TolFun',1e-5,...
                    'MaxIter',20,...
                    'MaxfunEval',10000);
P_opt = fmincon(@(optimum_vals)objfun(optimum_vals), x0,[],[],[],[],lb,ub,@(optimum_vals)nonlcon(optimum_vals),options);

disp('Optimized Parameters:')
R = P_opt(1);
r = P_opt(2);
l= P_opt(3);
c= P_opt(4);
d= P_opt(5);