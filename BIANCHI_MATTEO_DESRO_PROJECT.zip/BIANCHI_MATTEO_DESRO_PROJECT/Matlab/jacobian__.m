function [matrixA,matrixB] = jacobian(ro1, ro2, ro3,beta1,beta2,beta3, phi, r)
%matrix A = jacobian matrix , matrixB = inverse


%Jacobian matrix

%phi calculated for c1 c2 and c3 from positive x axis.
phi2 = phi + 2*pi/3; %phi plus 120
phi3 = phi + 4*pi/3; %phi plus 240

%calculating the unitvector a1 2 3
angleA1= 0 ; %in line with x axis
angleA2= 2*pi/3; %120 from x axis
angleA3= 4*pi/3; %240 from x axis;

a1 = [cos(angleA1); sin(angleA1)];
a2 = [cos(angleA2); sin(angleA2)];
a3 = [cos(angleA3); sin(angleA3)];

%calculating the unitvector b1 2 3
b1 = [cos(beta1); sin(beta1)];
b2 = [cos(beta2); sin(beta2)];
b3 = [cos(beta3); sin(beta3)];


%calculating the unitvector c1 2 3
angleC1= phi +pi/6;
angleC2= phi2+pi/6;
angleC3= phi3+pi/6;

e1 = [-cos(angleC1); -sin(angleC1)];
e2 = [-cos(angleC2); -sin(angleC2)];
e3 = [-cos(angleC3); -sin(angleC3)];


% the rotation matrix about pi/2
E = [0,-1;1,0];
matrixA = [transpose(b1), r*transpose(b1)*E*e1; transpose(b2), r*transpose(b2)*E*e2; transpose(b3), r*transpose(b3)*E*e3];
matrixB = [transpose(b1)*a1, 0, 0; 0, transpose(b2)*a2, 0; 0, 0, transpose(b3)*a3];
%J = inv(A)*B;
end

