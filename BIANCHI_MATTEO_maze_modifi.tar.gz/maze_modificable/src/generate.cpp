#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <maze.h>

typedef struct
{
    int x, y; //Node position - little waste of memory, but it allows faster generation
    void *parent; //Pointer to parent node
    char c; //Character to be displayed
    char dirs; //Directions that still haven't been explored
} Node;

Node *nodes; //Nodes array
int width = 51, height = 101, percent; //Maze dimensions (fixed) -> i preferred to use fixed dim for better understanding
//if i want i can change them or i can also give dimensions (and consider type)from prompt

int init()
{
    int i, j;
    Node *n;

    //Allocate memory for maze
    nodes = (Node *)calloc(width * height, sizeof(Node));
    if (nodes == NULL)
        return 1;

    //Setup crucial nodes
    for (i = 0; i < width; i++)
    {
        for (j = 0; j < height; j++)
        {
            n = nodes + i + j * width;
            if (i * j % 2)
            {
                n->x = i;
                n->y = j;
                n->dirs = 15; //Assume that all directions can be explored (4 youngest bits set)
                n->c = ' ';
            }
            else
                n->c = '#'; //Add walls between nodes
        }
    }
    return 0;
}

Node *linkNodes(Node *n)
{
    //Connects node to a random neighbor (if possible) and returns
    //address of the next node that should be visited

    int x, y;
    char dir;
    Node *dest;

    //Nothing can be done if null pointer is given - return
    if (n == NULL)
        return NULL;

    //While there are directions still unexplored
    while (n->dirs)
    {
        //Randomly pick one direction
        dir = (1 << (rand() % 4));

        //If it has already been explored - try again
        if (~n->dirs & dir)
            continue;

        //Mark direction as explored
        n->dirs &= ~dir;

        //Depending on the chosen direction
        switch (dir)
        {
        //Check if it's possible to go right
        case 1:
            if (n->x + 2 < width)
            {
                x = n->x + 2;
                y = n->y;
            }
            else
                continue;
            break;

        //Check if it's possible to go down
        case 2:
            if (n->y + 2 < height)
            {
                x = n->x;
                y = n->y + 2;
            }
            else
                continue;
            break;

        //Check if it's possible to go left
        case 4:
            if (n->x - 2 >= 0)
            {
                x = n->x - 2;
                y = n->y;
            }
            else
                continue;
            break;

        //Check if it's possible to go up
        case 8:
            if (n->y - 2 >= 0)
            {
                x = n->x;
                y = n->y - 2;
            }
            else
                continue;
            break;
        }

        //Get the destination node into a pointer (makes things a tiny bit faster)
        dest = nodes + x + y * width;

        //Make sure that the destination node is not a wall
        if (dest->c == ' ')
        {
            //If the destination is a linked node already - abort
            if (dest->parent != NULL)
                continue;

            //Otherwise, adopt the node
            dest->parent = n;

            //Remove the wall between nodes
            nodes[n->x + (x - n->x) / 2 + (n->y + (y - n->y) / 2) * width].c = ' ';

            //Return the address of the child node
            return dest;
        }
    }

    //If nothing more can be done here - return the parent's address
    return (Node *)n->parent;
}

void draw()
{
    int i, j;

    //Outputs the maze to the terminal - nothing special
    for (i = 0; i < height; i++)
    {
        for (j = 0; j < width; j++)
        {
            printf("%c", nodes[j + i * width].c);
        }
        printf("\n");
    }
}

int convert_to_2d(int i, int j)
{
    return j + width * i;
}

void makeEntries()
{
    int i;
    for (i = 0; i < width; i++)
    {
        if (nodes[convert_to_2d(1, i)].c == ' ')
        {
            printf("I'm here with at wall 1 : %d\n", i);
            nodes[convert_to_2d(0, i)].c = ' ';
            break;
        }
    }

    for (i = width - 1; i > 0; i--)
    {
        if (nodes[convert_to_2d(height - 2, i)].c == ' ')
        {
            printf("I'm here with at wall 2 : %d\n", i);
            nodes[convert_to_2d(height - 1, i)].c = ' ';
            break;
        }
    }
}

void generateMaze(const char *path)
{
    int i, j;
    ecn::Maze maze = ecn::Maze(height, width);
    for (i = 0; i < height; i++)
    {
        for (j = 0; j < width; j++)
        {
            if (nodes[j + i * width].c == ' ')
                maze.dig(i, j);
        }
    }
    maze.save(); // Save the maze to the default file (maze.png)
}

int main()
{
    Node *start, *last;
    char maze_name[50];

    // Seed random generator
    srand(time(NULL));

    // Initialize maze
    if (init())
    {
        fprintf(stderr, "Out of memory!\n");
        exit(1);
    }

    start = nodes + 1 + width;
    start->parent = start;
    last = start;
    while ((last = linkNodes(last)) != start);
    // Here the maze is fully generated
    makeEntries();

    draw();
    sprintf(maze_name, "../mazes/maze_ %d _ %d .png", height, width);
    generateMaze(maze_name);
}
