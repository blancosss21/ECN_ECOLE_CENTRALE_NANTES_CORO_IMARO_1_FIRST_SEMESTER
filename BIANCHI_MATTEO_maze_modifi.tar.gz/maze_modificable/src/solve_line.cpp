#include <a_star.h>
#include <maze.h>

using namespace std;
using namespace ecn;

class Position : public Point
{
    typedef std::unique_ptr<Position> PositionPtr;

public:
    // Constructor with distance parameter
    Position(int _x, int _y, int distance) : Point(_x, _y), distance_(distance) {}

    // Constructor from coordinates
    Position(int _x, int _y) : Point(_x, _y), distance_(1) {}

    // Constructor from base ecn::Point
    Position(ecn::Point p) : Point(p.x, p.y), distance_(1) {}

    int distToParent()
    {
        // Return the stored distance to the parent
        return distance_;
    }

    std::vector<PositionPtr> children()
    {
        // This method should return all positions reachable from this one
        std::vector<PositionPtr> generated;

        // Check if the next position is part of a corridor
        if (is_corridor(this->x - 1, this->y))
            generated.push_back(PositionPtr(new Position(this->x - 1, this->y, distance_ + 1)));

        if (is_corridor(this->x + 1, this->y))
            generated.push_back(PositionPtr(new Position(this->x + 1, this->y, distance_ + 1)));

        if (is_corridor(this->x, this->y - 1))
            generated.push_back(PositionPtr(new Position(this->x, this->y - 1, distance_ + 1)));

        if (is_corridor(this->x, this->y + 1))
            generated.push_back(PositionPtr(new Position(this->x, this->y + 1, distance_ + 1)));

        return generated;
    }

    // Utility function to check if the position is part of a corridor
    bool is_corridor(int x, int y)
    {
        // Implement the logic for checking if the position is part of a corridor
        // You may need to access the maze object to check for free cells

        // Example: Check if the cell at (x, y) is free in the maze
        return maze.isFree(x, y);
    }

private:
    int distance_; // Distance to the parent
};

int main(int argc, char **argv)
{
    // Load file
    std::string filename = Maze::mazeFile("maze.png");
    if (argc == 2)
        filename = std::string(argv[1]);

    // Let Point know about this maze
    Position::maze.load(filename);

    // Initial and goal positions as Position's
    Position start = Position::maze.start(),
             goal = Position::maze.end();

    // Call A* algorithm
    ecn::Astar(start, goal);

    // Save final image
    Position::maze.saveSolution("line");
    cv::waitKey(0);
}




///ANOTHER TYPE OF SOLUTION (DYNAMIC)
//int main( int argc, char **argv )
//{
//    // load file
//    std::string filename = "maze.png",solution_name;
//    if(argc == 2)
//        filename = std::string(argv[1]);

//    // let Point know about this maze
//    Position::maze.load(filename);

//    // initial and goal positions as Position's
//    Position start = Position::maze.start(),goal = Position::maze.end();
//    // call A* algorithm
//    ecn::Astar(start, goal);

//    solution_name = "line"+to_string(Position::maze.height())+"_"+to_string(Position::maze.width());
//    std::cout << solution_name << std::endl;
//    // save final image
//    Position::maze.saveSolution(solution_name);
//    cv::waitKey(0);
//}
