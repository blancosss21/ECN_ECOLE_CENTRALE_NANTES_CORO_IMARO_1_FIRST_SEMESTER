#include <a_star.h>
#include <maze.h>
#include <opencv2/opencv.hpp>


using namespace std;
using namespace ecn;

class Position : public Point
{
    typedef std::unique_ptr<Position> PositionPtr;

public:
    Position(int _x, int _y) : Point(_x, _y) {}

    Position(ecn::Point p) : Point(p.x, p.y) {}

    Position(int _x, int _y, int distance) : Point(_x, _y), distance(distance) {}

    bool isValid(int x, int y)
    {
        return x >= 0 && x < maze.width() && y >= 0 && y < maze.height();
    }


    void PrintPoint()
    {
        printf("(%d,%d)\n", this->x, this->y);
    }

    void PrintValue()
    {
        printf("Value : %d\n", Position::maze.isFree(this->x, this->y));
    }

    int getNbWalls()
    {
        int sum = Position::maze.isFree(x, y - 1);
        sum += Position::maze.isFree(x + 1, y);
        sum += Position::maze.isFree(x, y + 1);
        sum += Position::maze.isFree(x - 1, y);
        return sum;
    }

    bool isIntersection()
    {
        return getNbWalls() <= 1;
    }

    bool isDeadEnd()
    {
        return getNbWalls() >= 3;
    }

    bool isCorner()
    {
        bool A, B, C, D, A_, B_, C_, D_;
        A = Position::maze.isFree(x, y - 1);
        B = Position::maze.isFree(x + 1, y);
        C = Position::maze.isFree(x, y + 1);
        D = Position::maze.isFree(x - 1, y);
        A_ = !A;
        B_ = !B;
        C_ = !C;
        D_ = !D;
        return (A and B and C_ and D_) or (A and B_ and C_ and D) or (A_ and B_ and C and D) or (A_ and B and C and D_);
    }

    bool isCornerUpRight()
    {
        bool A, B, C, D, A_, B_, C_, D_;
        A = Position::maze.isFree(x, y - 1);
        B = Position::maze.isFree(x + 1, y);
        C = Position::maze.isFree(x, y + 1);
        D = Position::maze.isFree(x - 1, y);
        A_ = !A;
        B_ = !B;
        C_ = !C;
        D_ = !D;
        return A_ and B_ and C and D;
    }

    bool isCornerUpLeft()
    {
        bool A, B, C, D, A_, B_, C_, D_;
        A = Position::maze.isFree(x, y - 1);
        B = Position::maze.isFree(x + 1, y);
        C = Position::maze.isFree(x, y + 1);
        D = Position::maze.isFree(x - 1, y);
        A_ = !A;
        B_ = !B;
        C_ = !C;
        D_ = !D;
        return A_ and D_ and B and C;
    }

    bool isCornerDownRight()
    {
        bool A, B, C, D, A_, B_, C_, D_;
        A = Position::maze.isFree(x, y - 1);
        B = Position::maze.isFree(x + 1, y);
        C = Position::maze.isFree(x, y + 1);
        D = Position::maze.isFree(x - 1, y);
        A_ = !A;
        B_ = !B;
        C_ = !C;
        D_ = !D;
        return A and D and B_ and C_;
    }

    bool isCornerDownLeft()
    {
        bool A, B, C, D, A_, B_, C_, D_;
        A = Position::maze.isFree(x, y - 1);
        B = Position::maze.isFree(x + 1, y);
        C = Position::maze.isFree(x, y + 1);
        D = Position::maze.isFree(x - 1, y);
        A_ = !A;
        B_ = !B;
        C_ = !C;
        D_ = !D;

        return A and B and C_ and D_;
    }

    int getDistance(int x1, int y1)
    {
        return abs(x - x1) + abs(y - y1);
    }

    bool isCorridor(int x1, int y1)
    {
        int switcher = 0;
        if (!Position::maze.isFree(x1, y1))
            return false;
        else
        {
            // Print information for debugging
            std::cout << "Checking corridor at (" << x1 << "," << y1 << ")" << std::endl;

            // walk in the x direction
            while (!(x1 == x && y1 == y) && Position::maze.isFree(x1, y1) &&
                   !Position(x1, y1).isDeadEnd() && !Position(x1, y1).isIntersection())
            {
                if (Position(x1, y1).isCorner())
                    switcher = 1 - switcher;

                // Update x1 and y1 based on switcher
                x1 += (1 - switcher) * (x - x1) / abs(x - x1);
                y1 += switcher * (y - y1) / abs(y - y1);

                // Print intermediate steps for debugging
                std::cout << "Intermediate position: (" << x1 << "," << y1 << ")" << std::endl;
            }

            // Check if the final position is the same as the current position
            return x1 == x && y1 == y;
        }
    }


    int distToParent()
    {
        return this->distance;
    }

    std::vector<PositionPtr> children()
    {
        std::vector<PositionPtr> generated;

        // Generate children in each direction
        generateChildrenInDirection(1, 0, generated); // right
        generateChildrenInDirection(-1, 0, generated); // left
        generateChildrenInDirection(0, 1, generated); // down
        generateChildrenInDirection(0, -1, generated); // up

        // Print information for debugging
        for (auto &pos : generated)
        {
            pos->PrintPoint();
            pos->PrintValue();
        }

        return generated;
    }


    void generateChildrenInDirection(int dx, int dy, std::vector<PositionPtr> &generated)
    {
        int i = 0, j = 0;

        // Check if the next position is valid and free
        while (Position::isValid(x + i + dx, y + j + dy) && Position::maze.isFree(x + i + dx, y + j + dy))
        {
            i += dx;
            j += dy;

            // Check if the current position is the goal
            if (Position(x + i, y + j) == Position::maze.end())
            {
                generated.push_back(PositionPtr(new Position(x + i, y + j, this->distance + abs(i) + abs(j))));
                return; // Stop exploration if the goal is reached
            }

            // Add the generated position to the vector
            generated.push_back(PositionPtr(new Position(x + i, y + j, this->distance + abs(i) + abs(j))));
        }
    }





protected:
    int distance;
};

int main(int argc, char **argv)
{
    std::string filename = Maze::mazeFile("maze.png");
    if (argc == 2)
        filename = std::string(argv[1]);

    Position::maze.load(filename);

    Position start = Position::maze.start(),
             goal = Position::maze.end();

    ecn::Astar(start, goal);

    Position::maze.saveSolution("corridor");
    cv::waitKey(0);
}




///ANOTHER TYPE OF SOLUTION (DYNAMIC)
//int main( int argc, char **argv )
//{
//    // load file
//    std::string filename = "maze.png",solution_name;
//    if(argc == 2)
//        filename = std::string(argv[1]);

//    // let Point know about this maze
//    Position::maze.load(filename);

//    // initial and goal positions as Position's
//    Position start = Position::maze.start(),goal = Position::maze.end();
//    // call A* algorithm
//    ecn::Astar(start, goal);

//    solution_name = "corridor"+to_string(Position::maze.height())+"_"+to_string(Position::maze.width());
//    std::cout << solution_name << std::endl;
//    // save final image
//    Position::maze.saveSolution(solution_name);
//    cv::waitKey(0);

//}
